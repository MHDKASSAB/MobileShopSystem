﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop_Managment
{
    public partial class Mobiles : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public Mobiles()
        {
            InitializeComponent();
            MobilesUpdate();
        }
        public void Clear()
        {
            mobid_txt.Text = "الرقم Number";
            brand_txt.Text = "الماركة Brand";
            model_txt.Text = "الطراز Model";
            price_txt.Text = "السعر Price";
            qty_txt.Text = "الكمية Quantity";
            status_combobox.SelectedIndex = -1;
            mobdetails_txt.Text = "العلامات المميزة Special Marks";
        }
        public void MobilesUpdate()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select * from Mobiles", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            mobiles_dvg.DataSource = ds.Tables[0];
            con.Close();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Hide();
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            if (mobid_txt.Text == "الرقم Number" ||
            brand_txt.Text == "الماركة Brand" ||
            model_txt.Text == "الطراز Model" ||
            price_txt.Text == "السعر Price" ||
            qty_txt.Text == "الكمية Quantity" ||
            status_combobox.SelectedIndex == -1 ||
            mobdetails_txt.Text == "العلامات المميزة Special Marks")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (mobid_txt.Text == "" ||
            brand_txt.Text == "" ||
            model_txt.Text == "" ||
            price_txt.Text == "" ||
            qty_txt.Text == "" ||
            status_combobox.SelectedIndex == -1 ||
            mobdetails_txt.Text == "")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Insert into Mobiles (MobID , MobBrand , MobModel , MobPrice , MobQuantity , MobStatus , MobDetails , Addedat)" +
                        "Values ('" + mobid_txt.Text + "' , '" + brand_txt.Text + "' , '" + model_txt.Text + "' , '" + price_txt.Text + "'  , '" + qty_txt.Text + "','" + status_combobox.SelectedItem.ToString() + "','" + mobdetails_txt.Text + "', '" + DateTime.Today + "')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Mobile Added Successfully تمت إضافة الهاتف المحمول بنجاح", "Add New Mobile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    MobilesUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void edit_btn_Click(object sender, EventArgs e)
        {

            if (mobid_txt.Text == "الرقم Number" ||
            brand_txt.Text == "الماركة Brand" ||
            model_txt.Text == "الطراز Model" ||
            price_txt.Text == "السعر Price" ||
            qty_txt.Text == "الكمية Quantity" ||
            status_combobox.SelectedIndex == -1 ||
            mobdetails_txt.Text == "العلامات المميزة Special Marks")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (mobid_txt.Text == "" ||
            brand_txt.Text == "" ||
            model_txt.Text == "" ||
            price_txt.Text == "" ||
            qty_txt.Text == "" ||
            status_combobox.SelectedIndex == -1 ||
            mobdetails_txt.Text == "")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Update Mobiles set [MobBrand] = '" + brand_txt.Text + "' , [MobModel] = '" + model_txt.Text + "' , [MobPrice] = '" + price_txt.Text + "' ," +
                        "[MobQuantity] = '"+qty_txt.Text+"' , [MobStatus] = '"+status_combobox.SelectedItem.ToString()+"' , [MobDetails] = '"+mobdetails_txt.Text+"'" +
                        "Where [MobID] = '" + mobid_txt.Text + "')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Mobile Updated Successfully \n تمت تحديث معلومات الهاتف المحمول بنجاح", "Update Mobile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    MobilesUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void del_btn_Click(object sender, EventArgs e)
        {
            if (mobid_txt.Text == null)
            {
                MessageBox.Show("Select Mobile !! \n اختر الهاتف المحمول !! ", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (mobid_txt.Text == "الرقم Number")
            {
                MessageBox.Show("Select Mobile !! \n اختر الهاتف المحمول !! ", "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Delete Mobiles where MobID = '" + mobid_txt.Text + "'", con);
                    com.ExecuteNonQuery();
                    if (MessageBox.Show("Do You Want Delete this Mobile ? \n هل تريد حذف هذا الهاتف المحمول؟", "Delete Mobile", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        MessageBox.Show("Mobile Deleted Successfully \n تم حذف الهاتف المحمول بنجاح ", "Delete Mobile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    con.Close();
                    MobilesUpdate();
                    Clear();
                    add_btn.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Mobile Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void mobiles_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            add_btn.Enabled = false;

            int i = e.RowIndex;
            DataGridViewRow row = mobiles_dvg.Rows[i];
            mobid_txt.Text = row.Cells[0].Value.ToString();
            brand_txt.Text = row.Cells[1].Value.ToString();
            model_txt.Text = row.Cells[2].Value.ToString();
            price_txt.Text = row.Cells[3].Value.ToString();
            qty_txt.Text = row.Cells[4].Value.ToString();
            status_combobox.SelectedItem = row.Cells[5].Value.ToString();
            mobdetails_txt.Text = row.Cells[6].Value.ToString();
        }

        private void mobiles_lbl_Click(object sender, EventArgs e)
        {
            Mobiles mobiles = new Mobiles();
            mobiles.Show();
            this.Hide();
        }

        private void Mobiles_Load(object sender, EventArgs e)
        {

        }
    }
}
