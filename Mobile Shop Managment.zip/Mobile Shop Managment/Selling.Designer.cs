﻿namespace Mobile_Shop_Managment
{
    partial class Selling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Selling));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            Selling selling = this;
            selling.search_txt = new ns1.BunifuMaterialTextbox();
            this.search_btn = new System.Windows.Forms.PictureBox();
            this.close_btn = new System.Windows.Forms.PictureBox();
            this.mobiles_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.client_txt = new ns1.BunifuMaterialTextbox();
            this.price_txt = new ns1.BunifuMaterialTextbox();
            this.product_txt = new ns1.BunifuMaterialTextbox();
            this.qty_txt = new ns1.BunifuMaterialTextbox();
            this.add_btn = new System.Windows.Forms.PictureBox();
            this.back_btn = new System.Windows.Forms.PictureBox();
            this.accessories_dvg = new ns1.BunifuCustomDataGrid();
            this.mobiles_dvg = new ns1.BunifuCustomDataGrid();
            this.invoices_dvg = new ns1.BunifuCustomDataGrid();
            this.label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.print_btn = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.syp_lbl = new System.Windows.Forms.Label();
            this.salesamount_lbl = new System.Windows.Forms.Label();
            this.invoiceamount_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accessories_dvg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobiles_dvg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoices_dvg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.print_btn)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // search_txt
            // 
            this.search_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.search_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_txt.ForeColor = System.Drawing.Color.Silver;
            this.search_txt.HintForeColor = System.Drawing.Color.Empty;
            this.search_txt.HintText = "";
            this.search_txt.isPassword = false;
            this.search_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineThickness = 1;
            this.search_txt.Location = new System.Drawing.Point(786, 93);
            this.search_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.search_txt.Name = "search_txt";
            this.search_txt.Size = new System.Drawing.Size(196, 50);
            this.search_txt.TabIndex = 4;
            this.search_txt.Text = "البحث Search";
            this.search_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // search_btn
            // 
            this.search_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.search_btn.Image = ((System.Drawing.Image)(resources.GetObject("search_btn.Image")));
            this.search_btn.Location = new System.Drawing.Point(750, 103);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(30, 30);
            this.search_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.search_btn.TabIndex = 31;
            this.search_btn.TabStop = false;
            // 
            // close_btn
            // 
            this.close_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close_btn.Image = ((System.Drawing.Image)(resources.GetObject("close_btn.Image")));
            this.close_btn.Location = new System.Drawing.Point(2, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(44, 44);
            this.close_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close_btn.TabIndex = 32;
            this.close_btn.TabStop = false;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // mobiles_lbl
            // 
            this.mobiles_lbl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mobiles_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mobiles_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobiles_lbl.ForeColor = System.Drawing.Color.Silver;
            this.mobiles_lbl.Location = new System.Drawing.Point(839, 8);
            this.mobiles_lbl.Name = "mobiles_lbl";
            this.mobiles_lbl.Size = new System.Drawing.Size(91, 69);
            this.mobiles_lbl.TabIndex = 30;
            this.mobiles_lbl.Text = "المبيعات\r\nSales";
            this.mobiles_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Hacen Tunisia", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1000, 84);
            this.label2.TabIndex = 29;
            this.label2.Text = "Mobile Shop Managment System";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(783, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // client_txt
            // 
            this.client_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.client_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.client_txt.ForeColor = System.Drawing.Color.Silver;
            this.client_txt.HintForeColor = System.Drawing.Color.Empty;
            this.client_txt.HintText = "";
            this.client_txt.isPassword = false;
            this.client_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.client_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.client_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.client_txt.LineThickness = 1;
            this.client_txt.Location = new System.Drawing.Point(742, 150);
            this.client_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.client_txt.Name = "client_txt";
            this.client_txt.Size = new System.Drawing.Size(196, 50);
            this.client_txt.TabIndex = 0;
            this.client_txt.Text = "الزبون Client";
            this.client_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // price_txt
            // 
            this.price_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.price_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price_txt.ForeColor = System.Drawing.Color.Silver;
            this.price_txt.HintForeColor = System.Drawing.Color.Empty;
            this.price_txt.HintText = "";
            this.price_txt.isPassword = false;
            this.price_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineThickness = 1;
            this.price_txt.Location = new System.Drawing.Point(742, 266);
            this.price_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.price_txt.Name = "price_txt";
            this.price_txt.Size = new System.Drawing.Size(196, 50);
            this.price_txt.TabIndex = 2;
            this.price_txt.Text = "السعر Price";
            this.price_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // product_txt
            // 
            this.product_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.product_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product_txt.ForeColor = System.Drawing.Color.Silver;
            this.product_txt.HintForeColor = System.Drawing.Color.Empty;
            this.product_txt.HintText = "";
            this.product_txt.isPassword = false;
            this.product_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.product_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.product_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.product_txt.LineThickness = 1;
            this.product_txt.Location = new System.Drawing.Point(742, 208);
            this.product_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.product_txt.Name = "product_txt";
            this.product_txt.Size = new System.Drawing.Size(196, 50);
            this.product_txt.TabIndex = 1;
            this.product_txt.Text = "المنتج Product";
            this.product_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // qty_txt
            // 
            this.qty_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qty_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qty_txt.ForeColor = System.Drawing.Color.Silver;
            this.qty_txt.HintForeColor = System.Drawing.Color.Empty;
            this.qty_txt.HintText = "";
            this.qty_txt.isPassword = false;
            this.qty_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineThickness = 1;
            this.qty_txt.Location = new System.Drawing.Point(742, 324);
            this.qty_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qty_txt.Name = "qty_txt";
            this.qty_txt.Size = new System.Drawing.Size(196, 50);
            this.qty_txt.TabIndex = 3;
            this.qty_txt.Text = "الكمية Quantity";
            this.qty_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // add_btn
            // 
            this.add_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_btn.Image = ((System.Drawing.Image)(resources.GetObject("add_btn.Image")));
            this.add_btn.Location = new System.Drawing.Point(818, 381);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(44, 44);
            this.add_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.add_btn.TabIndex = 37;
            this.add_btn.TabStop = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_btn.Image = ((System.Drawing.Image)(resources.GetObject("back_btn.Image")));
            this.back_btn.Location = new System.Drawing.Point(956, 636);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(44, 44);
            this.back_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.back_btn.TabIndex = 38;
            this.back_btn.TabStop = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // accessories_dvg
            // 
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.accessories_dvg.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.accessories_dvg.BackgroundColor = System.Drawing.Color.Blue;
            this.accessories_dvg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.accessories_dvg.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.accessories_dvg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.accessories_dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.accessories_dvg.DoubleBuffered = true;
            this.accessories_dvg.EnableHeadersVisualStyles = false;
            this.accessories_dvg.HeaderBgColor = System.Drawing.SystemColors.Info;
            this.accessories_dvg.HeaderForeColor = System.Drawing.Color.Blue;
            this.accessories_dvg.Location = new System.Drawing.Point(12, 110);
            this.accessories_dvg.Name = "accessories_dvg";
            this.accessories_dvg.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.accessories_dvg.RowHeadersWidth = 62;
            this.accessories_dvg.RowTemplate.Height = 28;
            this.accessories_dvg.Size = new System.Drawing.Size(340, 208);
            this.accessories_dvg.TabIndex = 39;
            this.accessories_dvg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.accessories_dvg_CellContentClick);
            // 
            // mobiles_dvg
            // 
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.mobiles_dvg.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.mobiles_dvg.BackgroundColor = System.Drawing.Color.Blue;
            this.mobiles_dvg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mobiles_dvg.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.mobiles_dvg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.mobiles_dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mobiles_dvg.DoubleBuffered = true;
            this.mobiles_dvg.EnableHeadersVisualStyles = false;
            this.mobiles_dvg.HeaderBgColor = System.Drawing.SystemColors.Info;
            this.mobiles_dvg.HeaderForeColor = System.Drawing.Color.Blue;
            this.mobiles_dvg.Location = new System.Drawing.Point(358, 110);
            this.mobiles_dvg.Name = "mobiles_dvg";
            this.mobiles_dvg.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.mobiles_dvg.RowHeadersWidth = 62;
            this.mobiles_dvg.RowTemplate.Height = 28;
            this.mobiles_dvg.Size = new System.Drawing.Size(360, 208);
            this.mobiles_dvg.TabIndex = 39;
            this.mobiles_dvg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mobiles_dvg_CellContentClick);
            // 
            // invoices_dvg
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.invoices_dvg.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.invoices_dvg.BackgroundColor = System.Drawing.Color.Blue;
            this.invoices_dvg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.invoices_dvg.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.invoices_dvg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.invoices_dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invoices_dvg.DoubleBuffered = true;
            this.invoices_dvg.EnableHeadersVisualStyles = false;
            this.invoices_dvg.HeaderBgColor = System.Drawing.SystemColors.Info;
            this.invoices_dvg.HeaderForeColor = System.Drawing.Color.Blue;
            this.invoices_dvg.Location = new System.Drawing.Point(8, 368);
            this.invoices_dvg.Name = "invoices_dvg";
            this.invoices_dvg.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.invoices_dvg.RowHeadersWidth = 62;
            this.invoices_dvg.RowTemplate.Height = 28;
            this.invoices_dvg.Size = new System.Drawing.Size(706, 208);
            this.invoices_dvg.TabIndex = 39;
            this.invoices_dvg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invoices_dvg_CellContentClick);
            // 
            // label
            // 
            this.label.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Silver;
            this.label.Location = new System.Drawing.Point(438, 64);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(201, 43);
            this.label.TabIndex = 40;
            this.label.Text = "الهواتف المحمولة Mobiles";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(82, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 32);
            this.label1.TabIndex = 40;
            this.label1.Text = "الملحقات Accessories\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Silver;
            this.label3.Location = new System.Drawing.Point(283, 321);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 44);
            this.label3.TabIndex = 40;
            this.label3.Text = "الفواتير Invoices";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // print_btn
            // 
            this.print_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.print_btn.Image = ((System.Drawing.Image)(resources.GetObject("print_btn.Image")));
            this.print_btn.Location = new System.Drawing.Point(818, 431);
            this.print_btn.Name = "print_btn";
            this.print_btn.Size = new System.Drawing.Size(44, 44);
            this.print_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.print_btn.TabIndex = 35;
            this.print_btn.TabStop = false;
            this.print_btn.Click += new System.EventHandler(this.print_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.syp_lbl);
            this.panel1.Controls.Add(this.salesamount_lbl);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(730, 481);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(220, 100);
            this.panel1.TabIndex = 41;
            // 
            // syp_lbl
            // 
            this.syp_lbl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.syp_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.syp_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.syp_lbl.ForeColor = System.Drawing.Color.White;
            this.syp_lbl.Location = new System.Drawing.Point(0, 54);
            this.syp_lbl.Name = "syp_lbl";
            this.syp_lbl.Size = new System.Drawing.Size(220, 46);
            this.syp_lbl.TabIndex = 40;
            this.syp_lbl.Text = "ليرة سورية SYP";
            this.syp_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // salesamount_lbl
            // 
            this.salesamount_lbl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.salesamount_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.salesamount_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesamount_lbl.ForeColor = System.Drawing.Color.Black;
            this.salesamount_lbl.Location = new System.Drawing.Point(35, 0);
            this.salesamount_lbl.Name = "salesamount_lbl";
            this.salesamount_lbl.Size = new System.Drawing.Size(150, 54);
            this.salesamount_lbl.TabIndex = 40;
            this.salesamount_lbl.Text = "مبلغ المبيعات\r\nSales Amount";
            this.salesamount_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // invoiceamount_lbl
            // 
            this.invoiceamount_lbl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.invoiceamount_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.invoiceamount_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoiceamount_lbl.ForeColor = System.Drawing.Color.Silver;
            this.invoiceamount_lbl.Location = new System.Drawing.Point(283, 579);
            this.invoiceamount_lbl.Name = "invoiceamount_lbl";
            this.invoiceamount_lbl.Size = new System.Drawing.Size(150, 54);
            this.invoiceamount_lbl.TabIndex = 40;
            this.invoiceamount_lbl.Text = "مبلغ الفاتورة\r\nInvoice Amount";
            this.invoiceamount_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Hacen Tunisia", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Silver;
            this.label4.Location = new System.Drawing.Point(415, 581);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 50);
            this.label4.TabIndex = 40;
            this.label4.Text = "ليرة سورية SYP";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // Selling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1000, 678);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.invoiceamount_lbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label);
            this.Controls.Add(this.mobiles_dvg);
            this.Controls.Add(this.invoices_dvg);
            this.Controls.Add(this.accessories_dvg);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.print_btn);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.qty_txt);
            this.Controls.Add(this.client_txt);
            this.Controls.Add(this.price_txt);
            this.Controls.Add(this.product_txt);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.search_txt);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.mobiles_lbl);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Selling";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Selling";
            this.Load += new System.EventHandler(this.Selling_Load);
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accessories_dvg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobiles_dvg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoices_dvg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.print_btn)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ns1.BunifuMaterialTextbox search_txt;
        private System.Windows.Forms.PictureBox search_btn;
        private System.Windows.Forms.PictureBox close_btn;
        private System.Windows.Forms.Label mobiles_lbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox add_btn;
        private System.Windows.Forms.PictureBox back_btn;
        private ns1.BunifuCustomDataGrid accessories_dvg;
        private ns1.BunifuCustomDataGrid mobiles_dvg;
        private ns1.BunifuCustomDataGrid invoices_dvg;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox print_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label syp_lbl;
        private System.Windows.Forms.Label salesamount_lbl;
        private System.Windows.Forms.Label invoiceamount_lbl;
        private System.Windows.Forms.Label label4;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        public ns1.BunifuMaterialTextbox client_txt;
        public ns1.BunifuMaterialTextbox price_txt;
        public ns1.BunifuMaterialTextbox product_txt;
        public ns1.BunifuMaterialTextbox qty_txt;
    }
}