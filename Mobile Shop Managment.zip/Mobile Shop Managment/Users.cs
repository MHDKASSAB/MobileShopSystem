﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop_Managment
{
    public partial class Users : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public Users()
        {
            InitializeComponent();
            UsersUpdate();
        }
        public void Clear()
        {
            username_txt.Text = "UserName اسم المستخدم";
            password_txt.Text = "PassWord كلمة المرور";
            fullname_txt.Text = "FullName الاسم الكامل";
            mobile_txt.Text = "Mobile رقم الموبايل";
        }
        public void UsersUpdate()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select * from Users", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            users_dvg.DataSource = ds.Tables[0];
            con.Close();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            AdminMainMenu adminMainMenu = new AdminMainMenu();
            adminMainMenu.Show();
            this.Hide();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Users_Load(object sender, EventArgs e)
        {

        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            if (username_txt.Text == "UserName اسم المستخدم" ||
            password_txt.Text == "PassWord كلمة المرور" ||
            fullname_txt.Text == "FullName الاسم الكامل" ||
            mobile_txt.Text == "Mobile رقم الموبايل") 
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(username_txt.Text == "" ||
            password_txt.Text == "" ||
            fullname_txt.Text == "" ||
            mobile_txt.Text == "")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Insert into Users (UserName , PassWord , FullName , Mobiile, Addedat) Values ('" + username_txt.Text + "' , '" + password_txt.Text + "' , '" + fullname_txt.Text + "' , '" + mobile_txt.Text + "' , '"+DateTime.Today+"')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("User Added Successfully تمت إضافة المستخدم بنجاح", "Add New User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    UsersUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void edit_btn_Click(object sender, EventArgs e)
        {

            if (username_txt.Text == "UserName اسم المستخدم" ||
            password_txt.Text == "PassWord كلمة المرور" ||
            fullname_txt.Text == "FullName الاسم الكامل" ||
            mobile_txt.Text == "Mobile رقم الموبايل")
            {
                MessageBox.Show("Missing Information \n خطأ في المعلومات", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (username_txt.Text == "" ||
            password_txt.Text == "" ||
            fullname_txt.Text == "" ||
            mobile_txt.Text == "")
            {
                MessageBox.Show("Missing Information \n خطأ في المعلومات", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Update Users set [PassWord] = '"+password_txt.Text+"' , [FullName] = '"+fullname_txt.Text+ "' , [Mobiile] = '" + mobile_txt.Text+"'" +
                        "Where [UserName] = '"+username_txt.Text+"')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("User Updated Successfully \n تمت تحديث معلومات المستخدم بنجاح", "Update User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    UsersUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void del_btn_Click(object sender, EventArgs e)
        {
            if (username_txt.Text == null)
            {
                MessageBox.Show("Select User !! \n اختر المستخدم !! ", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (username_txt.Text == "UserName اسم المستخدم")
            {
                MessageBox.Show("Select User !! \n اختر المستخدم !! ", "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Delete Users where UserName = '" + username_txt.Text + "'", con);
                    com.ExecuteNonQuery();
                    if(MessageBox.Show("Do You Want Delete this User ? \n هل تريد حذف هذا المستخدم؟", "Delete User", MessageBoxButtons.YesNo, MessageBoxIcon.Information)==DialogResult.Yes)
                    {
                       MessageBox.Show("User Deleted Successfully \n تم حذف المستخدم بنجاح ", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    con.Close();
                    UsersUpdate();
                    Clear();
                    add_btn.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "User Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void users_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            add_btn.Enabled = false;

            int i = e.RowIndex;
            DataGridViewRow row = users_dvg.Rows[i];
            username_txt.Text = row.Cells[0].Value.ToString();
            password_txt.Text = row.Cells[1].Value.ToString();
            fullname_txt.Text = row.Cells[2].Value.ToString();
            mobile_txt.Text = row.Cells[3].Value.ToString();
        }

        private void users_lbl_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            this.Hide();
        }
    }
}
