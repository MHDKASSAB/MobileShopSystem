﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop_Managment
{
    public partial class MainMenu : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public MainMenu()
        {
            InitializeComponent();
        }


        private void close_btn_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void users_btn_Click(object sender, EventArgs e)
        {
            Users users = new Users();
            users.Show();
            this.Hide();
        }

        private void mobiles_btn_Click(object sender, EventArgs e)
        {
            Mobiles mobiles = new Mobiles();
            mobiles.Show();
            this.Hide();
        }

        private void accessories_btn_Click(object sender, EventArgs e)
        {
            Accessories accessories = new Accessories();
            accessories.Show();
            this.Hide();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            LogIn logIn = new LogIn();
            logIn.Show();
            this.Hide();
        }

        private void invoices_btn_Click(object sender, EventArgs e)
        {
            Selling selling = new Selling();
            selling.Show();
            this.Hide();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
