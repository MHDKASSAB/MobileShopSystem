﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop_Managment
{
    public partial class Accessories : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public Accessories()
        {
            InitializeComponent();
            AccessoriesUpdate();
        }
        public void Clear()
        {
            accessid_txt.Text = "الرقم Number";
            brand_txt.Text = "الماركة Brand";
            type_txt.Text = "النوع Type";
            price_txt.Text = "السعر Price";
            qty_txt.Text = "الكمية Quantity";
        }
        public void AccessoriesUpdate()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select * from Accessories", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            accessories_dvg.DataSource = ds.Tables[0];
            con.Close();
        }
        private void back_btn_Click(object sender, EventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Hide();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            if (accessid_txt.Text == "الرقم Number"||
            brand_txt.Text == "الماركة Brand"||
            type_txt.Text == "النوع Type"||
            price_txt.Text == "السعر Price"||
            qty_txt.Text == "الكمية Quantity")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (accessid_txt.Text == "" ||
            brand_txt.Text == "" ||
            type_txt.Text == "" ||
            price_txt.Text == "" ||
            qty_txt.Text == "")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Insert into Accessories (AcID , AcBrand , AcType , AcPrice , AcQuantity , Addedat)" +
                        "Values ('" + accessid_txt.Text + "' , '" + brand_txt.Text + "' , '" + type_txt.Text + "' , '" + price_txt.Text + "'  , '" + qty_txt.Text + "', '" + DateTime.Today + "')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Accessories Added Successfully تمت إضافة الملحقات بنجاح", "Add New Accessories", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    AccessoriesUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void edit_btn_Click(object sender, EventArgs e)
        {
            if (accessid_txt.Text == "الرقم Number" ||
            brand_txt.Text == "الماركة Brand" ||
            type_txt.Text == "النوع Type" ||
            price_txt.Text == "السعر Price" ||
            qty_txt.Text == "الكمية Quantity")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (accessid_txt.Text == "" ||
            brand_txt.Text == "" ||
            type_txt.Text == "" ||
            price_txt.Text == "" ||
            qty_txt.Text == "")
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Update Accessories set [AcBrand] = '" + brand_txt.Text + "' , [AcType] = '" + type_txt.Text + "' , [AcPrice] = '" + price_txt.Text + "' ," +
                        "[AcQuantity] = '" + qty_txt.Text + "'" +
                        "Where [AcID] = '" + accessid_txt.Text + "')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Accessories Updated Successfully \n تمت تحديث معلومات الملحقات بنجاح", "Update Accessories", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    AccessoriesUpdate();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void del_btn_Click(object sender, EventArgs e)
        {
            if (accessid_txt.Text == null)
            {
                MessageBox.Show("Select Accessories !! \n اختر الملحقات !! ", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (accessid_txt.Text == "الرقم Number")
            {
                MessageBox.Show("Select Accessories !! \n اختر الملحقات !! ", "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Delete Accessories where AcID = '" + accessid_txt.Text + "'", con);
                    com.ExecuteNonQuery();
                    if (MessageBox.Show("Do You Want Delete this Accessories ? \n هل تريد حذف هذه الملحقات؟", "Delete Accessories", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        MessageBox.Show("Accessories Deleted Successfully \n تم حذف الملحقات بنجاح ", "Delete Accessories", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    con.Close();
                    AccessoriesUpdate();
                    Clear();
                    add_btn.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Accessories Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void accessories_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            add_btn.Enabled = false;

            int i = e.RowIndex;
            DataGridViewRow row = accessories_dvg.Rows[i];
            accessid_txt.Text = row.Cells[0].Value.ToString();
            brand_txt.Text = row.Cells[1].Value.ToString();
            type_txt.Text = row.Cells[2].Value.ToString();
            price_txt.Text = row.Cells[3].Value.ToString();
            qty_txt.Text = row.Cells[4].Value.ToString();
        }

        private void accessories_lbl_Click_1(object sender, EventArgs e)
        {
            Accessories accessories = new Accessories();
            accessories.Show();
            this.Hide();
        }

        private void Accessories_Load(object sender, EventArgs e)
        {

        }
    }
}
