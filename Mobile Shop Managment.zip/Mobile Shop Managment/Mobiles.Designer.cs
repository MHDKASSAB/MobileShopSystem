﻿namespace Mobile_Shop_Managment
{
    partial class Mobiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mobiles));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mobiles_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.close_btn = new System.Windows.Forms.PictureBox();
            this.back_btn = new System.Windows.Forms.PictureBox();
            this.qty_txt = new ns1.BunifuMaterialTextbox();
            this.price_txt = new ns1.BunifuMaterialTextbox();
            this.model_txt = new ns1.BunifuMaterialTextbox();
            this.brand_txt = new ns1.BunifuMaterialTextbox();
            this.mobid_txt = new ns1.BunifuMaterialTextbox();
            this.status_combobox = new System.Windows.Forms.ComboBox();
            this.mobdetails_txt = new ns1.BunifuMaterialTextbox();
            this.search_txt = new ns1.BunifuMaterialTextbox();
            this.search_btn = new System.Windows.Forms.PictureBox();
            this.add_btn = new System.Windows.Forms.PictureBox();
            this.edit_btn = new System.Windows.Forms.PictureBox();
            this.del_btn = new System.Windows.Forms.PictureBox();
            this.clear_btn = new System.Windows.Forms.PictureBox();
            this.mobiles_dvg = new ns1.BunifuCustomDataGrid();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.del_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clear_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobiles_dvg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mobiles_lbl
            // 
            this.mobiles_lbl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mobiles_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mobiles_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobiles_lbl.ForeColor = System.Drawing.Color.Silver;
            this.mobiles_lbl.Location = new System.Drawing.Point(765, 5);
            this.mobiles_lbl.Name = "mobiles_lbl";
            this.mobiles_lbl.Size = new System.Drawing.Size(235, 75);
            this.mobiles_lbl.TabIndex = 12;
            this.mobiles_lbl.Text = "بيانات الهواتف المحمولة\r\nMobiles Details\r\n";
            this.mobiles_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mobiles_lbl.Click += new System.EventHandler(this.mobiles_lbl_Click);
            // 
            // label2
            // 
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Hacen Tunisia", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1000, 84);
            this.label2.TabIndex = 11;
            this.label2.Text = "Mobile Shop Managment System";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // close_btn
            // 
            this.close_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close_btn.Image = ((System.Drawing.Image)(resources.GetObject("close_btn.Image")));
            this.close_btn.Location = new System.Drawing.Point(2, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(44, 44);
            this.close_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close_btn.TabIndex = 13;
            this.close_btn.TabStop = false;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_btn.Image = ((System.Drawing.Image)(resources.GetObject("back_btn.Image")));
            this.back_btn.Location = new System.Drawing.Point(956, 557);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(44, 44);
            this.back_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.back_btn.TabIndex = 14;
            this.back_btn.TabStop = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // qty_txt
            // 
            this.qty_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.qty_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qty_txt.ForeColor = System.Drawing.Color.Silver;
            this.qty_txt.HintForeColor = System.Drawing.Color.Empty;
            this.qty_txt.HintText = "";
            this.qty_txt.isPassword = false;
            this.qty_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.qty_txt.LineThickness = 1;
            this.qty_txt.Location = new System.Drawing.Point(2, 158);
            this.qty_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qty_txt.Name = "qty_txt";
            this.qty_txt.Size = new System.Drawing.Size(178, 50);
            this.qty_txt.TabIndex = 4;
            this.qty_txt.Text = "الكمية Quantity";
            this.qty_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // price_txt
            // 
            this.price_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.price_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.price_txt.ForeColor = System.Drawing.Color.Silver;
            this.price_txt.HintForeColor = System.Drawing.Color.Empty;
            this.price_txt.HintText = "";
            this.price_txt.isPassword = false;
            this.price_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.price_txt.LineThickness = 1;
            this.price_txt.Location = new System.Drawing.Point(186, 158);
            this.price_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.price_txt.Name = "price_txt";
            this.price_txt.Size = new System.Drawing.Size(196, 50);
            this.price_txt.TabIndex = 3;
            this.price_txt.Text = "السعر Price";
            this.price_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // model_txt
            // 
            this.model_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.model_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_txt.ForeColor = System.Drawing.Color.Silver;
            this.model_txt.HintForeColor = System.Drawing.Color.Empty;
            this.model_txt.HintText = "";
            this.model_txt.isPassword = false;
            this.model_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.model_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.model_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.model_txt.LineThickness = 1;
            this.model_txt.Location = new System.Drawing.Point(388, 158);
            this.model_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.model_txt.Name = "model_txt";
            this.model_txt.Size = new System.Drawing.Size(196, 50);
            this.model_txt.TabIndex = 2;
            this.model_txt.Text = "الطراز Model";
            this.model_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // brand_txt
            // 
            this.brand_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.brand_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brand_txt.ForeColor = System.Drawing.Color.Silver;
            this.brand_txt.HintForeColor = System.Drawing.Color.Empty;
            this.brand_txt.HintText = "";
            this.brand_txt.isPassword = false;
            this.brand_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.brand_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.brand_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.brand_txt.LineThickness = 1;
            this.brand_txt.Location = new System.Drawing.Point(590, 158);
            this.brand_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.brand_txt.Name = "brand_txt";
            this.brand_txt.Size = new System.Drawing.Size(196, 50);
            this.brand_txt.TabIndex = 1;
            this.brand_txt.Text = "الماركة Brand";
            this.brand_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // mobid_txt
            // 
            this.mobid_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mobid_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobid_txt.ForeColor = System.Drawing.Color.Silver;
            this.mobid_txt.HintForeColor = System.Drawing.Color.Empty;
            this.mobid_txt.HintText = "";
            this.mobid_txt.isPassword = false;
            this.mobid_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.mobid_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.mobid_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.mobid_txt.LineThickness = 1;
            this.mobid_txt.Location = new System.Drawing.Point(792, 158);
            this.mobid_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mobid_txt.Name = "mobid_txt";
            this.mobid_txt.Size = new System.Drawing.Size(196, 50);
            this.mobid_txt.TabIndex = 0;
            this.mobid_txt.Text = "الرقم Number";
            this.mobid_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // status_combobox
            // 
            this.status_combobox.BackColor = System.Drawing.Color.Blue;
            this.status_combobox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.status_combobox.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_combobox.ForeColor = System.Drawing.Color.Silver;
            this.status_combobox.FormattingEnabled = true;
            this.status_combobox.Items.AddRange(new object[] {
            "New",
            "Used"});
            this.status_combobox.Location = new System.Drawing.Point(590, 240);
            this.status_combobox.Name = "status_combobox";
            this.status_combobox.Size = new System.Drawing.Size(196, 34);
            this.status_combobox.TabIndex = 5;
            this.status_combobox.Text = "الحالة Status";
            // 
            // mobdetails_txt
            // 
            this.mobdetails_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mobdetails_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobdetails_txt.ForeColor = System.Drawing.Color.Silver;
            this.mobdetails_txt.HintForeColor = System.Drawing.Color.Empty;
            this.mobdetails_txt.HintText = "";
            this.mobdetails_txt.isPassword = false;
            this.mobdetails_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.mobdetails_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.mobdetails_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.mobdetails_txt.LineThickness = 1;
            this.mobdetails_txt.Location = new System.Drawing.Point(186, 220);
            this.mobdetails_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mobdetails_txt.Name = "mobdetails_txt";
            this.mobdetails_txt.Size = new System.Drawing.Size(398, 50);
            this.mobdetails_txt.TabIndex = 6;
            this.mobdetails_txt.Text = "العلامات المميزة Special Marks";
            this.mobdetails_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // search_txt
            // 
            this.search_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.search_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_txt.ForeColor = System.Drawing.Color.Silver;
            this.search_txt.HintForeColor = System.Drawing.Color.Empty;
            this.search_txt.HintText = "";
            this.search_txt.isPassword = false;
            this.search_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineThickness = 1;
            this.search_txt.Location = new System.Drawing.Point(792, 100);
            this.search_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.search_txt.Name = "search_txt";
            this.search_txt.Size = new System.Drawing.Size(196, 50);
            this.search_txt.TabIndex = 11;
            this.search_txt.Text = "البحث Search";
            this.search_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // search_btn
            // 
            this.search_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.search_btn.Image = ((System.Drawing.Image)(resources.GetObject("search_btn.Image")));
            this.search_btn.Location = new System.Drawing.Point(756, 114);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(30, 30);
            this.search_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.search_btn.TabIndex = 13;
            this.search_btn.TabStop = false;
            // 
            // add_btn
            // 
            this.add_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_btn.Image = ((System.Drawing.Image)(resources.GetObject("add_btn.Image")));
            this.add_btn.Location = new System.Drawing.Point(902, 226);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(44, 44);
            this.add_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.add_btn.TabIndex = 13;
            this.add_btn.TabStop = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // edit_btn
            // 
            this.edit_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_btn.Image = ((System.Drawing.Image)(resources.GetObject("edit_btn.Image")));
            this.edit_btn.Location = new System.Drawing.Point(852, 226);
            this.edit_btn.Name = "edit_btn";
            this.edit_btn.Size = new System.Drawing.Size(44, 44);
            this.edit_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.edit_btn.TabIndex = 13;
            this.edit_btn.TabStop = false;
            this.edit_btn.Click += new System.EventHandler(this.edit_btn_Click);
            // 
            // del_btn
            // 
            this.del_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.del_btn.Image = ((System.Drawing.Image)(resources.GetObject("del_btn.Image")));
            this.del_btn.Location = new System.Drawing.Point(802, 226);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(44, 44);
            this.del_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.del_btn.TabIndex = 13;
            this.del_btn.TabStop = false;
            this.del_btn.Click += new System.EventHandler(this.del_btn_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_btn.Image = ((System.Drawing.Image)(resources.GetObject("clear_btn.Image")));
            this.clear_btn.Location = new System.Drawing.Point(136, 226);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(44, 44);
            this.clear_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.clear_btn.TabIndex = 13;
            this.clear_btn.TabStop = false;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // mobiles_dvg
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.mobiles_dvg.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.mobiles_dvg.BackgroundColor = System.Drawing.Color.Blue;
            this.mobiles_dvg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mobiles_dvg.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.mobiles_dvg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.mobiles_dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mobiles_dvg.DoubleBuffered = true;
            this.mobiles_dvg.EnableHeadersVisualStyles = false;
            this.mobiles_dvg.HeaderBgColor = System.Drawing.SystemColors.Info;
            this.mobiles_dvg.HeaderForeColor = System.Drawing.Color.Blue;
            this.mobiles_dvg.Location = new System.Drawing.Point(8, 280);
            this.mobiles_dvg.Name = "mobiles_dvg";
            this.mobiles_dvg.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.mobiles_dvg.RowHeadersWidth = 62;
            this.mobiles_dvg.RowTemplate.Height = 28;
            this.mobiles_dvg.Size = new System.Drawing.Size(980, 271);
            this.mobiles_dvg.TabIndex = 16;
            this.mobiles_dvg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mobiles_dvg_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(719, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // Mobiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.mobiles_dvg);
            this.Controls.Add(this.status_combobox);
            this.Controls.Add(this.search_txt);
            this.Controls.Add(this.mobid_txt);
            this.Controls.Add(this.mobdetails_txt);
            this.Controls.Add(this.qty_txt);
            this.Controls.Add(this.price_txt);
            this.Controls.Add(this.model_txt);
            this.Controls.Add(this.brand_txt);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.edit_btn);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.mobiles_lbl);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Mobiles";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mobiles";
            this.Load += new System.EventHandler(this.Mobiles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.del_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clear_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mobiles_dvg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label mobiles_lbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox close_btn;
        private System.Windows.Forms.PictureBox back_btn;
        private ns1.BunifuMaterialTextbox qty_txt;
        private ns1.BunifuMaterialTextbox price_txt;
        private ns1.BunifuMaterialTextbox model_txt;
        private ns1.BunifuMaterialTextbox brand_txt;
        private ns1.BunifuMaterialTextbox mobid_txt;
        private System.Windows.Forms.ComboBox status_combobox;
        private ns1.BunifuMaterialTextbox mobdetails_txt;
        private ns1.BunifuMaterialTextbox search_txt;
        private System.Windows.Forms.PictureBox search_btn;
        private System.Windows.Forms.PictureBox add_btn;
        private System.Windows.Forms.PictureBox edit_btn;
        private System.Windows.Forms.PictureBox del_btn;
        private System.Windows.Forms.PictureBox clear_btn;
        private ns1.BunifuCustomDataGrid mobiles_dvg;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}