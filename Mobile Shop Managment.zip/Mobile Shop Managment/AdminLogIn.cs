﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop_Managment
{
    public partial class AdminLogIn : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public AdminLogIn()
        {
            InitializeComponent();
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            LogIn logIn = new LogIn();
            logIn.Show();
            this.Hide();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            if (password_txt.Text == "Password")
            {
                AdminMainMenu adminmainMenu = new AdminMainMenu();
                adminmainMenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Admin Password \nكلمة مرور المسؤول خاطئة", "Admin LogIn Error" , MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void AdminLogIn_Load(object sender, EventArgs e)
        {

        }
    }
}
