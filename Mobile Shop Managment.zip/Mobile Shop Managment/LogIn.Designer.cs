﻿namespace Mobile_Shop_Managment
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogIn));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.logasadmin_lbl = new System.Windows.Forms.Label();
            this.login_btn = new ns1.BunifuFlatButton();
            this.password_txt = new ns1.BunifuMaterialTextbox();
            this.username_txt = new ns1.BunifuMaterialTextbox();
            this.close_btn = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Info;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.logasadmin_lbl);
            this.panel1.Controls.Add(this.login_btn);
            this.panel1.Controls.Add(this.password_txt);
            this.panel1.Controls.Add(this.username_txt);
            this.panel1.ForeColor = System.Drawing.Color.Blue;
            this.panel1.Location = new System.Drawing.Point(46, 25);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel1.Size = new System.Drawing.Size(451, 542);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(160, 107);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 130);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Hacen Tunisia", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(451, 104);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mobile Shop Managment System";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logasadmin_lbl
            // 
            this.logasadmin_lbl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logasadmin_lbl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logasadmin_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logasadmin_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logasadmin_lbl.ForeColor = System.Drawing.Color.Silver;
            this.logasadmin_lbl.Location = new System.Drawing.Point(0, 487);
            this.logasadmin_lbl.Name = "logasadmin_lbl";
            this.logasadmin_lbl.Size = new System.Drawing.Size(451, 55);
            this.logasadmin_lbl.TabIndex = 2;
            this.logasadmin_lbl.Text = "LogIn As Admin\r\nتسجيل الدخول كمسؤول";
            this.logasadmin_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.logasadmin_lbl.Click += new System.EventHandler(this.logasadmin_lbl_Click);
            // 
            // login_btn
            // 
            this.login_btn.Activecolor = System.Drawing.Color.Blue;
            this.login_btn.BackColor = System.Drawing.Color.Blue;
            this.login_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.login_btn.BorderRadius = 0;
            this.login_btn.ButtonText = "LogIn";
            this.login_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.login_btn.DisabledColor = System.Drawing.SystemColors.Info;
            this.login_btn.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.login_btn.ForeColor = System.Drawing.SystemColors.Info;
            this.login_btn.Iconcolor = System.Drawing.Color.Silver;
            this.login_btn.Iconimage = null;
            this.login_btn.Iconimage_right = null;
            this.login_btn.Iconimage_right_Selected = null;
            this.login_btn.Iconimage_Selected = null;
            this.login_btn.IconMarginLeft = 0;
            this.login_btn.IconMarginRight = 0;
            this.login_btn.IconRightVisible = true;
            this.login_btn.IconRightZoom = 0D;
            this.login_btn.IconVisible = true;
            this.login_btn.IconZoom = 90D;
            this.login_btn.IsTab = false;
            this.login_btn.Location = new System.Drawing.Point(25, 411);
            this.login_btn.Margin = new System.Windows.Forms.Padding(6, 9, 6, 9);
            this.login_btn.Name = "login_btn";
            this.login_btn.Normalcolor = System.Drawing.Color.Blue;
            this.login_btn.OnHovercolor = System.Drawing.Color.Silver;
            this.login_btn.OnHoverTextColor = System.Drawing.Color.Blue;
            this.login_btn.selected = true;
            this.login_btn.Size = new System.Drawing.Size(401, 77);
            this.login_btn.TabIndex = 2;
            this.login_btn.Text = "LogIn";
            this.login_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.login_btn.Textcolor = System.Drawing.Color.White;
            this.login_btn.TextFont = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // password_txt
            // 
            this.password_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_txt.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.password_txt.ForeColor = System.Drawing.Color.Silver;
            this.password_txt.HintForeColor = System.Drawing.Color.Empty;
            this.password_txt.HintText = "";
            this.password_txt.isPassword = true;
            this.password_txt.LineFocusedColor = System.Drawing.Color.Blue;
            this.password_txt.LineIdleColor = System.Drawing.Color.Silver;
            this.password_txt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.password_txt.LineThickness = 1;
            this.password_txt.Location = new System.Drawing.Point(25, 327);
            this.password_txt.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.password_txt.Name = "password_txt";
            this.password_txt.Size = new System.Drawing.Size(401, 69);
            this.password_txt.TabIndex = 1;
            this.password_txt.Text = "PassWord";
            this.password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // username_txt
            // 
            this.username_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.username_txt.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.username_txt.ForeColor = System.Drawing.Color.Silver;
            this.username_txt.HintForeColor = System.Drawing.Color.Empty;
            this.username_txt.HintText = "";
            this.username_txt.isPassword = false;
            this.username_txt.LineFocusedColor = System.Drawing.Color.Blue;
            this.username_txt.LineIdleColor = System.Drawing.Color.Silver;
            this.username_txt.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.username_txt.LineThickness = 1;
            this.username_txt.Location = new System.Drawing.Point(25, 246);
            this.username_txt.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.username_txt.Name = "username_txt";
            this.username_txt.Size = new System.Drawing.Size(401, 69);
            this.username_txt.TabIndex = 0;
            this.username_txt.Text = "UserName اسم المستخدم";
            this.username_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // close_btn
            // 
            this.close_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close_btn.Image = ((System.Drawing.Image)(resources.GetObject("close_btn.Image")));
            this.close_btn.Location = new System.Drawing.Point(503, 1);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(44, 44);
            this.close_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close_btn.TabIndex = 4;
            this.close_btn.TabStop = false;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(548, 600);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "LogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.LogIn_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label logasadmin_lbl;
        private ns1.BunifuFlatButton login_btn;
        private ns1.BunifuMaterialTextbox password_txt;
        private ns1.BunifuMaterialTextbox username_txt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox close_btn;
        private System.Windows.Forms.Label label2;
    }
}