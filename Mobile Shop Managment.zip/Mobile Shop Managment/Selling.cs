﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mobile_Shop_Managment
{
    public partial class Selling : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=MobileShopDB;Integrated Security=True");
        public Selling()
        {
            InitializeComponent();
            SalesUpdate();
        }
        public void Mobileselling()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select MobBrand , MobModel , MobPrice from Mobiles", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            mobiles_dvg.DataSource = ds.Tables[0];
            con.Close();
        }
        public void Accessorieselling()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select AcBrand , AcType , AcPrice from Accessories", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            accessories_dvg.DataSource = ds.Tables[0];
            con.Close();
        }
        public void SalesUpdate()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter();
            sda = new SqlDataAdapter("Select * from Sales", con);
            SqlCommandBuilder scb = new SqlCommandBuilder();
            scb = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            invoices_dvg.DataSource = ds.Tables[0];
            con.Close();
        }
        public void Clear()
        {
            client_txt.Text = "الزبون Client";
            product_txt.Text = "المنتج Product";
            price_txt.Text = "السعر Price";
            qty_txt.Text = "الكمية Quantity";
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Hide();
        }

        private void Selling_Load(object sender, EventArgs e)
        {
            Mobileselling();
            Accessorieselling();
            sum();
        }
        private void sum ()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum (Total) From Sales", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            salesamount_lbl.Text = dt.Rows[0][0].ToString();
            con.Close();
        }

        private void mobiles_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            DataGridViewRow row = mobiles_dvg.Rows[i];
            product_txt.Text = row.Cells[0].Value.ToString() + " " + row.Cells[1].Value.ToString();
            price_txt.Text = row.Cells[2].Value.ToString();
        }

        private void accessories_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            DataGridViewRow row = accessories_dvg.Rows[i];
            product_txt.Text = row.Cells[0].Value.ToString() +" "+ row.Cells[1].Value.ToString();
            price_txt.Text = row.Cells[2].Value.ToString();
        }

        private void invoices_dvg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            if (client_txt.Text == "الزبون Client" ||
            product_txt.Text == "المنتج Product" ||
            price_txt.Text == "السعر Price" ||
            qty_txt.Text == "الكمية Quantity"
            )
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Sales Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (client_txt.Text == "" ||
            product_txt.Text == "" ||
            price_txt.Text == "" ||
            qty_txt.Text == ""
            )
            {
                MessageBox.Show("Missing Information خطأ في المعلومات", "Sales Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int GrdTotal = 0;
                    int Total = Convert.ToInt32(qty_txt.Text) * Convert.ToInt32(price_txt.Text);
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com = new SqlCommand("Insert into Sales (Client , Product , Price , Total , Quantity , Addedat)" +
                        "Values ('" + client_txt.Text + "' , '" + product_txt.Text + "' , '" + price_txt.Text + "' , '" + Total + "'  , '" + qty_txt.Text + "' , '" + DateTime.Today + "')", con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Invoice Added Successfully تمت إضافة الفاتورة بنجاح", "Add New Invoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    SalesUpdate();
                    Clear();
                    GrdTotal = GrdTotal + Total;
                    invoiceamount_lbl.Text = "" + GrdTotal;
                    sum();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Invoice Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        int prodid, prodqty, prodprice, prodtotal, pos = 60;
        string prodname , prodclient , proddate;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("DatHat For Managment System", new Font("Hacen Tunisia", 18, FontStyle.Bold), Brushes.Red, new Point(80));
            e.Graphics.DrawString("ID Product Price Quantity Total", new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(26, 40));

            foreach(DataGridViewRow row in invoices_dvg.Rows)
            {
                prodid = Convert.ToInt32(row.Cells[0].Value);
                prodclient = "" + row.Cells[1].Value;
                prodname = ""+row.Cells[2].Value;
                prodprice = Convert.ToInt32(row.Cells[3].Value);
                prodtotal = Convert.ToInt32(row.Cells[4].Value);
                prodqty = Convert.ToInt32(row.Cells[5].Value);
                proddate = "" + row.Cells[6].Value;

                e.Graphics.DrawString("" + prodid, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(26, pos));
                e.Graphics.DrawString("" + prodclient, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(35, pos));
                e.Graphics.DrawString("" + prodname, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(45, pos));
                e.Graphics.DrawString("" + prodprice, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(120, pos));
                e.Graphics.DrawString("" + prodtotal, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(235, pos));
                e.Graphics.DrawString("" + prodqty, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(170, pos));
                e.Graphics.DrawString("" + proddate, new Font("Hacen Tunisia", 10, FontStyle.Bold), Brushes.Black, new Point(250, pos));

                pos = pos + 20;
            }
            e.Graphics.DrawString("Total : SYP" + invoiceamount_lbl.Text, new Font("Hacen Tunisia", 16, FontStyle.Bold), Brushes.Black, new Point(50, pos + 50));
            e.Graphics.DrawString("DatHat For Managment System", new Font("Hacen Tunisia", 18, FontStyle.Bold), Brushes.Red, new Point(10, pos + 80));
            invoices_dvg.Rows.Clear();
            invoices_dvg.Refresh();
            pos = 100;
            sum();
        }

        private void print_btn_Click(object sender, EventArgs e)
        {
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 400, 600);
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }
    }
}
