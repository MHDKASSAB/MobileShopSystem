﻿namespace Mobile_Shop_Managment
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Users));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.password_txt = new ns1.BunifuMaterialTextbox();
            this.username_txt = new ns1.BunifuMaterialTextbox();
            this.fullname_txt = new ns1.BunifuMaterialTextbox();
            this.mobile_txt = new ns1.BunifuMaterialTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.close_btn = new System.Windows.Forms.PictureBox();
            this.users_dvg = new ns1.BunifuCustomDataGrid();
            this.users_lbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.del_btn = new System.Windows.Forms.PictureBox();
            this.edit_btn = new System.Windows.Forms.PictureBox();
            this.add_btn = new System.Windows.Forms.PictureBox();
            this.clear_btn = new System.Windows.Forms.PictureBox();
            this.search_txt = new ns1.BunifuMaterialTextbox();
            this.search_btn = new System.Windows.Forms.PictureBox();
            this.back_btn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.users_dvg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.del_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clear_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // password_txt
            // 
            this.password_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_txt.ForeColor = System.Drawing.Color.Silver;
            this.password_txt.HintForeColor = System.Drawing.Color.Empty;
            this.password_txt.HintText = "";
            this.password_txt.isPassword = false;
            this.password_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.password_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.password_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.password_txt.LineThickness = 1;
            this.password_txt.Location = new System.Drawing.Point(718, 237);
            this.password_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.password_txt.Name = "password_txt";
            this.password_txt.Size = new System.Drawing.Size(241, 50);
            this.password_txt.TabIndex = 1;
            this.password_txt.Text = "PassWord كلمة المرور";
            this.password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // username_txt
            // 
            this.username_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.username_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_txt.ForeColor = System.Drawing.Color.Silver;
            this.username_txt.HintForeColor = System.Drawing.Color.Empty;
            this.username_txt.HintText = "";
            this.username_txt.isPassword = false;
            this.username_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.username_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.username_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.username_txt.LineThickness = 1;
            this.username_txt.Location = new System.Drawing.Point(718, 179);
            this.username_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.username_txt.Name = "username_txt";
            this.username_txt.Size = new System.Drawing.Size(241, 50);
            this.username_txt.TabIndex = 0;
            this.username_txt.Text = "UserName اسم المستخدم";
            this.username_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // fullname_txt
            // 
            this.fullname_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fullname_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullname_txt.ForeColor = System.Drawing.Color.Silver;
            this.fullname_txt.HintForeColor = System.Drawing.Color.Empty;
            this.fullname_txt.HintText = "";
            this.fullname_txt.isPassword = false;
            this.fullname_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.fullname_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.fullname_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.fullname_txt.LineThickness = 1;
            this.fullname_txt.Location = new System.Drawing.Point(718, 295);
            this.fullname_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fullname_txt.Name = "fullname_txt";
            this.fullname_txt.Size = new System.Drawing.Size(241, 50);
            this.fullname_txt.TabIndex = 2;
            this.fullname_txt.Text = "FullName الاسم الكامل";
            this.fullname_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // mobile_txt
            // 
            this.mobile_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.mobile_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobile_txt.ForeColor = System.Drawing.Color.Silver;
            this.mobile_txt.HintForeColor = System.Drawing.Color.Empty;
            this.mobile_txt.HintText = "";
            this.mobile_txt.isPassword = false;
            this.mobile_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.mobile_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.mobile_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.mobile_txt.LineThickness = 1;
            this.mobile_txt.Location = new System.Drawing.Point(718, 353);
            this.mobile_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mobile_txt.Name = "mobile_txt";
            this.mobile_txt.Size = new System.Drawing.Size(241, 50);
            this.mobile_txt.TabIndex = 3;
            this.mobile_txt.Text = "Mobile رقم الموبايل";
            this.mobile_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Hacen Tunisia", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1000, 84);
            this.label2.TabIndex = 7;
            this.label2.Text = "Mobile Shop Managment System";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // close_btn
            // 
            this.close_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close_btn.Image = ((System.Drawing.Image)(resources.GetObject("close_btn.Image")));
            this.close_btn.Location = new System.Drawing.Point(2, 0);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(44, 44);
            this.close_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.close_btn.TabIndex = 8;
            this.close_btn.TabStop = false;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // users_dvg
            // 
            this.users_dvg.AllowUserToAddRows = false;
            this.users_dvg.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.users_dvg.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.users_dvg.BackgroundColor = System.Drawing.Color.Blue;
            this.users_dvg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.users_dvg.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.users_dvg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.users_dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.users_dvg.DoubleBuffered = true;
            this.users_dvg.EnableHeadersVisualStyles = false;
            this.users_dvg.HeaderBgColor = System.Drawing.Color.Blue;
            this.users_dvg.HeaderForeColor = System.Drawing.Color.Silver;
            this.users_dvg.Location = new System.Drawing.Point(8, 179);
            this.users_dvg.Name = "users_dvg";
            this.users_dvg.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.users_dvg.RowHeadersWidth = 62;
            this.users_dvg.RowTemplate.Height = 28;
            this.users_dvg.Size = new System.Drawing.Size(704, 287);
            this.users_dvg.TabIndex = 9;
            this.users_dvg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.users_dvg_CellContentClick);
            // 
            // users_lbl
            // 
            this.users_lbl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.users_lbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.users_lbl.Font = new System.Drawing.Font("Hacen Tunisia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.users_lbl.ForeColor = System.Drawing.Color.Silver;
            this.users_lbl.Location = new System.Drawing.Point(814, 8);
            this.users_lbl.Name = "users_lbl";
            this.users_lbl.Size = new System.Drawing.Size(174, 69);
            this.users_lbl.TabIndex = 10;
            this.users_lbl.Text = "بيانات المستخدمين\r\nUsers Details";
            this.users_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.users_lbl.Click += new System.EventHandler(this.users_lbl_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(758, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // del_btn
            // 
            this.del_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.del_btn.Image = ((System.Drawing.Image)(resources.GetObject("del_btn.Image")));
            this.del_btn.Location = new System.Drawing.Point(794, 422);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(44, 44);
            this.del_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.del_btn.TabIndex = 14;
            this.del_btn.TabStop = false;
            this.del_btn.Click += new System.EventHandler(this.del_btn_Click);
            // 
            // edit_btn
            // 
            this.edit_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_btn.Image = ((System.Drawing.Image)(resources.GetObject("edit_btn.Image")));
            this.edit_btn.Location = new System.Drawing.Point(844, 422);
            this.edit_btn.Name = "edit_btn";
            this.edit_btn.Size = new System.Drawing.Size(44, 44);
            this.edit_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.edit_btn.TabIndex = 15;
            this.edit_btn.TabStop = false;
            this.edit_btn.Click += new System.EventHandler(this.edit_btn_Click);
            // 
            // add_btn
            // 
            this.add_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_btn.Image = ((System.Drawing.Image)(resources.GetObject("add_btn.Image")));
            this.add_btn.Location = new System.Drawing.Point(894, 422);
            this.add_btn.Name = "add_btn";
            this.add_btn.Size = new System.Drawing.Size(44, 44);
            this.add_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.add_btn.TabIndex = 16;
            this.add_btn.TabStop = false;
            this.add_btn.Click += new System.EventHandler(this.add_btn_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_btn.Image = ((System.Drawing.Image)(resources.GetObject("clear_btn.Image")));
            this.clear_btn.Location = new System.Drawing.Point(744, 422);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(44, 44);
            this.clear_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.clear_btn.TabIndex = 17;
            this.clear_btn.TabStop = false;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // search_txt
            // 
            this.search_txt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.search_txt.Font = new System.Drawing.Font("Hacen Tunisia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_txt.ForeColor = System.Drawing.Color.Silver;
            this.search_txt.HintForeColor = System.Drawing.Color.Empty;
            this.search_txt.HintText = "";
            this.search_txt.isPassword = false;
            this.search_txt.LineFocusedColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineIdleColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineMouseHoverColor = System.Drawing.SystemColors.Info;
            this.search_txt.LineThickness = 1;
            this.search_txt.Location = new System.Drawing.Point(792, 122);
            this.search_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.search_txt.Name = "search_txt";
            this.search_txt.Size = new System.Drawing.Size(196, 50);
            this.search_txt.TabIndex = 4;
            this.search_txt.Text = "البحث Search";
            this.search_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // search_btn
            // 
            this.search_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.search_btn.Image = ((System.Drawing.Image)(resources.GetObject("search_btn.Image")));
            this.search_btn.Location = new System.Drawing.Point(758, 132);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(30, 30);
            this.search_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.search_btn.TabIndex = 19;
            this.search_btn.TabStop = false;
            // 
            // back_btn
            // 
            this.back_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_btn.Image = ((System.Drawing.Image)(resources.GetObject("back_btn.Image")));
            this.back_btn.Location = new System.Drawing.Point(956, 557);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(44, 44);
            this.back_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.back_btn.TabIndex = 11;
            this.back_btn.TabStop = false;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // Users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.search_txt);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.edit_btn);
            this.Controls.Add(this.add_btn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.back_btn);
            this.Controls.Add(this.users_lbl);
            this.Controls.Add(this.users_dvg);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mobile_txt);
            this.Controls.Add(this.fullname_txt);
            this.Controls.Add(this.password_txt);
            this.Controls.Add(this.username_txt);
            this.Font = new System.Drawing.Font("Hacen Tunisia", 12F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Users";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Users";
            this.Load += new System.EventHandler(this.Users_Load);
            ((System.ComponentModel.ISupportInitialize)(this.close_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.users_dvg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.del_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edit_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clear_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_btn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ns1.BunifuMaterialTextbox password_txt;
        private ns1.BunifuMaterialTextbox username_txt;
        private ns1.BunifuMaterialTextbox fullname_txt;
        private ns1.BunifuMaterialTextbox mobile_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox close_btn;
        private ns1.BunifuCustomDataGrid users_dvg;
        private System.Windows.Forms.Label users_lbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox del_btn;
        private System.Windows.Forms.PictureBox edit_btn;
        private System.Windows.Forms.PictureBox add_btn;
        private System.Windows.Forms.PictureBox clear_btn;
        private ns1.BunifuMaterialTextbox search_txt;
        private System.Windows.Forms.PictureBox search_btn;
        private System.Windows.Forms.PictureBox back_btn;
    }
}